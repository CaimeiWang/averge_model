from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import GridSearchCV, StratifiedKFold
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_auc_score, matthews_corrcoef, \
    confusion_matrix
from itertools import product

# evaluation metrics
def accuracy(y_true, y_pred):
    return accuracy_score(y_true, y_pred)


def precision(y_true, y_pred):
    return precision_score(y_true, y_pred, pos_label=1, average="binary")


def recall(y_true, y_pred):
    return recall_score(y_true, y_pred, pos_label=1, average="binary")


def auc(y_true, y_scores):
    return roc_auc_score(y_true, y_scores)


def mcc(y_true, y_pred):
    return matthews_corrcoef(y_true, y_pred)


def new_confusion_matrix(y_true, y_pred):
    return confusion_matrix(y_true, y_pred, labels=[0, 1])


def sp(y_true, y_pred):
    cm = new_confusion_matrix(y_true, y_pred)
    return cm[0, 0] * 1.0 / (cm[0, 0] + cm[0, 1])


if __name__ == '__main__':
    f=open('y.txt','r')
    y_pre=[]
    y=[]
    for i in f.readlines():
        y_pre.append(i.split('\t')[3:6])
    y_pre=np.array(y_pre)
    for i in range(y_pre.shape[0]):
        for j in range(y_pre.shape[1]):
            y.append([])
            for k in y_pre[i][j].split(',')[1:-1]:
                    y[-1].append(float(k))
    y=np.array(y)

    y_true=y[0]
    y_pred=[]
    y_scores=[]
    for i in range(30):
        y_pred.append(y[1+i*3])
        y_scores.append(y[2+i*3])
    y_pred=np.array(np.sum(y_pred, axis=0)/30)
    y_scores=np.array(np.sum(y_scores, axis=0)/30)
    for i in range(len(y_pred)):
        if y_pred[i]>0.5:
            y_pred[i]=1
        else:
            y_pred[i]=0
    for i in range(len(y_scores)):
        if y_scores[i]>0.5:
            y_scores[i]=1
        else:
            y_scores[i]=0
    accuracy=accuracy(y_true, y_pred)
    precision=precision(y_true, y_pred)
    recall=recall(y_true, y_pred)
    auc=auc(y_true, y_scores)
    mcc=mcc(y_true, y_pred)
    sp=sp(y_true, y_pred)
    print('accuracy={},precision={},recall={},auc={},mcc={},sp={}'.format(accuracy,precision,recall,auc,mcc,sp))









