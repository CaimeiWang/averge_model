f=open('y.txt')
print(f.readline())
print(f.readline())